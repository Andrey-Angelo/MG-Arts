"""
MODELOS: definem como os dados serão organizados no banco de dados.

Neste projeto, cada registro representa uma pergunta e a resposta
que o chatbot deve devolver quando reconhecer essa pergunta.
"""
from django.db import models


class RespostaChat(models.Model):
    # CharField guarda texto curto. max_length limita a pergunta a 250 caracteres.
    # unique=True impede duas linhas com a mesma pergunta.
    pergunta = models.CharField(max_length=250, unique=True)

    # TextField guarda texto de tamanho maior, adequado para a resposta.
    resposta = models.TextField()
    # categoria/tipo da pergunta e resposta
    categoria = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        # Ordena os registros alfabeticamente quando forem consultados.
        ordering = ['pergunta']
        # Nomes exibidos no Django Admin, em singular e plural.
        verbose_name = 'Resposta do chatbot'
        verbose_name_plural = 'Respostas do chatbot'

class HistoricoConversa(models.Model):
    pergunta = models.CharField(max_length=255)
    resposta = models.TextField()
    data_hora = models.DateTimeField(auto_now_add=True)


        # Define a representação textual do registro no Admin e em depuração.
    def __str__(self):
        return f"{self.data_hora.strftime('%d/%m/%Y %H:%M')} - {self.pergunta}"
