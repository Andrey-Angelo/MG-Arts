from django.contrib import admin
from .models import RespostaChat, HistoricoConversa


@admin.register(RespostaChat)
class RespostaChatAdmin(admin.ModelAdmin):
    list_display = ('pergunta', 'categoria', 'resposta')
    search_fields = ('pergunta', 'resposta', 'categoria')

@admin.register(HistoricoConversa)
class HistoricoConversaAdmin(admin.ModelAdmin):
    list_display = ('data_hora', 'pergunta', 'resposta')
    search_fields = ('pergunta', 'resposta')