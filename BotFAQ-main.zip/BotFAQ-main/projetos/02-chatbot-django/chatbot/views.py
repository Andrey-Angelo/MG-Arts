"""
VIEWS: recebem requisições HTTP, executam a lógica da aplicação
e devolvem uma resposta ao navegador.
"""
import json  # Converte texto JSON recebido em um dicionário Python.
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_POST
from .models import RespostaChat, HistoricoConversa # Importa o modelo definido em models.py.

# Conjunto inicial de perguntas e respostas para demonstrar o chatbot.
# Os dados serão cadastrados no banco quando a página inicial for acessada.
EXEMPLOS = [
    ("Geral", "olá", "Olá! Como posso ajudar você hoje? 😊"),
    ("FAQ", "ajuda", "Claro! Pergunte algo ou clique em um dos botões para começar."),
    # Envios e Prazos
    ("Envios e Prazos", "qual é o prazo de entrega?", "O prazo varia de acordo com a sua região e a modalidade de envio escolhida (Sedex, PAC ou transportadora). Você pode calcular o tempo e o valor exato informando seu CEP na página do carrinho."),
    ("Envios e Prazos", "vocês enviam para todo o brasil?", "Sim, realizamos entregas em todo o território nacional através de transportadoras parceiras e dos Correios."),
    ("Envios e Prazos", "como faço para rastrear o meu pedido?", "Assim que o seu pedido for despachado, você receberá um e-mail e uma notificação via WhatsApp com o código de rastreamento e o link para acompanhar a entrega."),
    # 👕 Tamanhos e Modelagem
    ("Tamanhos e Modelagem", "como sei qual é o tamanho ideal para mim?", "Disponibilizamos uma tabela de medidas detalhada em todas as páginas de produto. Recomendamos que você meça uma camiseta sua que vista bem e compare com as nossas dimensões antes de fechar o pedido."),
    ("Tamanhos e Modelagem", "as camisetas são unissex?", "Trabalhamos com diferentes modelagens. Temos opções de corte Tradicional (unissex), Baby Look (feminina) e Oversized. A modelagem exata está especificada na descrição de cada produto."),
    # 🔄 Trocas e Devoluções
    ("Trocas e Devoluções", "a camiseta não serviu. como faço para trocar?", "Você tem até 7 dias corridos após o recebimento para solicitar a troca ou devolução gratuita, desde que a peça não tenha sido lavada ou usada e esteja com a etiqueta original."),
    ("Trocas e Devoluções", "quem paga o frete em caso de troca?", "A primeira troca do seu pedido é por nossa conta. Nós geramos um código de postagem reversa para você enviar o produto de volta sem custos."),
    # 🧼 Cuidados com a Peça
    ("Cuidados com a Peça", "como devo lavar minha camiseta para ela durar mais?", "Recomendamos lavar as peças do avesso, evitar o uso de alvejantes e secar à sombra. Não utilize secadoras e evite passar o ferro diretamente sobre a estampa."),
    ("Cuidados com a Peça", "o tecido encolhe na primeira lavagem?", "Nossas camisetas são produzidas com malha pré-encolhida, reduzindo drasticamente o encolhimento. Contudo, o algodão pode apresentar uma variação natural de até 3% após a primeira lavagem se exposto a água morna ou secadoras."),
    # 💳 Pagamentos e Segurança
    ("Pagamentos e Segurança", "quais são as formas de pagamento aceitas?", "Aceitamos Pix (com aprovação imediata e desconto), boleto bancário e cartões de crédito das principais bandeiras, com opção de parcelamento."),
    ("Pagamentos e Segurança", "é seguro comprar no site?", "Sim, nosso site conta com certificados de segurança SSL que criptografam todos os seus dados financeiros, garantindo uma compra segura."),
]
def index(request):
    """
    Exibe a página principal do chatbot.

    request contém informações da requisição feita pelo navegador.
    get_or_create cria cada exemplo somente se ele ainda não existir,
    evitando duplicações ao atualizar a página.
    """
    for categoria, pergunta, resposta in EXEMPLOS:
        RespostaChat.objects.get_or_create(
            pergunta=pergunta,
            defaults={'resposta': resposta, 'categoria': categoria}
        )

    # render localiza o template HTML, processa as tags Django e o devolve.
    return render(request, 'chatbot/index.html')


@require_POST
def chat(request):
    """
    API do chatbot. Aceita somente requisições HTTP POST.
    Espera um corpo JSON semelhante a: {"pergunta": "olá"}
    e devolve JSON semelhante a: {"resposta": "Olá! ..."}.
    """
    try:
        # request.body contém os bytes enviados pelo navegador.
        # decode transforma bytes em texto; json.loads transforma JSON em dict.
        data = json.loads(request.body.decode('utf-8'))
    except (json.JSONDecodeError, UnicodeDecodeError):
        # HTTP 400 indica que a requisição veio com conteúdo inválido.
        return JsonResponse(
            {'resposta': 'Não consegui ler a mensagem. Tente novamente.'},
            status=400
        )

    # get evita erro se a chave não existir; str garante texto;
    # strip remove espaços nas pontas e lower padroniza para minúsculas.
    pergunta = str(data.get('pergunta', '')).strip().lower()

    if not pergunta:
        return JsonResponse(
            {'resposta': 'Digite uma pergunta para continuar.'},
            status=400
        )

    # ORM do Django: consulta a tabela sem escrever SQL diretamente.
    registro = RespostaChat.objects.filter(pergunta=pergunta).first()

    if registro:
        resposta = registro.resposta
    # Respostas simples para saudações mesmo que não estejam cadastradas.
    elif any(saudacao in pergunta for saudacao in ['olá', 'ola', 'oi', 'oii']):
        resposta = 'Olá! Que bom falar com você. Clique nos botões ou digite sua dúvida.'
    elif 'ajuda' in pergunta:
        resposta = 'Claro! Use os botões abaixo ou digite sua pergunta.'
    else:
        # Este chatbot usa correspondência simples de texto; não é IA generativa.
        resposta = 'Desculpe, não entendi sua pergunta. Por favor, tente uma das opções abaixo.'

    HistoricoConversa.objects.create(
        pergunta=pergunta,
        resposta=resposta
    )

    # JsonResponse converte o dicionário Python em JSON para o JavaScript.
    return JsonResponse({'resposta': resposta})