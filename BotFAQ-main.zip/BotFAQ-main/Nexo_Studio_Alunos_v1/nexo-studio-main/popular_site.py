import os
import django
from datetime import date

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from decimal import Decimal
from django.contrib.auth.models import User
from studio.models import StudioProfile, ListingPage, Offering, Activity, ChatbotRegra, FAQItem

EMAIL = 'Mgartsprofissional@gmail.com'
WHATSAPP = '(11) 95902-1157'

user, criado = User.objects.get_or_create(
    username='mgarts',
    defaults={'email': EMAIL, 'first_name': 'MG', 'last_name': 'Arts'},
)
if criado:
    user.set_password('mgarts@2026')
    user.save()

perfil, _ = StudioProfile.objects.update_or_create(
    slug='mg-arts',
    defaults={
        'owner': user,
        'name': 'MG Arts',
        'sector': 'varejo',
        'tagline': 'Tirando suas ideias do papel para transformar em memórias',
        'description': 'Canecas, camisetas, quebra-cabeças e bottons personalizados com arte autoral, feitos sob encomenda com acabamento profissional.',
        'email': EMAIL,
        'phone': WHATSAPP,
        'address': 'Atendimento online com envio para todo o Brasil',
        'primary_color': '#2563EB',
        'secondary_color': '#0F172A',
        'accent_color': '#EC4899',
        'published': True,
    },
)

ListingPage.objects.update_or_create(
    business=perfil,
    slug='inicio',
    defaults={
        'title': 'Início',
        'body': 'Bem-vindo à MG Arts! Conheça nossas estampas exclusivas em canecas, camisetas e bottons personalizados.',
        'menu_label': 'Início',
        'is_visible': True,
        'sort_order': 1,
    },
)

ofertas = [
    ('Caneca Personalizada', 'Caneca com estampa exclusiva, criada sob medida com cores vibrantes e acabamento resistente para o uso diário.', '39.90', 'static/images/caneca.jpg'),
    ('Camiseta / Blusa Estampada', 'Camiseta ou blusa com estampa artesanal em silk, durável, confortável e com design autoral.', '79.90', 'static/images/blusa.jpg'),
    ('Botton / Broche Personalizado', 'Botton ou broche com estampa colecionável, ideal para mochilas, jaquetas e presentes criativos.', '12.90', 'static/images/botton.jpg'),
]
for nome, descricao, preco, imagem in ofertas:
    Offering.objects.update_or_create(
        business=perfil,
        name=nome,
        defaults={
            'kind': 'produto',
            'description': descricao,
            'price': Decimal(preco),
            'image': imagem,
            'active': True,
        },
    )

atividades = [
    ('Coleção Flores do Cerrado', 'Galeria de estampas florais autorais aplicadas em canecas e camisetas, com paleta azul e rosa.'),
    ('Série Colecionável Pixel Art', 'Portfólio de estampas em pixel art transformadas em bottons e broches de edição limitada.'),
]
for titulo, notas in atividades:
    Activity.objects.update_or_create(
        business=perfil,
        title=titulo,
        defaults={
            'kind': 'outro',
            'status': 'concluida',
            'amount': Decimal('0'),
            'notes': notas,
            'activity_date': date.today(),
        },
    )

regras = [
    # Boas-vindas e Contato Generalizado
    ('Saudação inicial', 'olá, ola, bom dia, boa tarde, boa noite, oi, ajuda', 'Olá! Como posso ajudar você hoje? Escolha uma das opções abaixo ou digite sua pergunta. 😊', 'Geral'),
    ('Como entro em contato?', 'contato, contatos, telefone, whatsapp, email, e-mail, falar, instagram, suporte', 'Fale diretamente com a equipe da MG Arts pelo WhatsApp ' + WHATSAPP + ' ou pelo e-mail ' + EMAIL + '.', 'Contato'),

    # Envios e Prazos
    ('Qual é o prazo de entrega?', 'prazo, prazos, entrega, demora, quanto tempo, sedex, pac, transportadora', 'O prazo varia de acordo com a sua região e a modalidade de envio escolhida (Sedex, PAC ou transportadora). Você pode calcular o tempo e o valor exato informando seu CEP na página do carrinho.', 'Envios'),
    ('Vocês enviam para todo o Brasil?', 'envio para todo o brasil, todo o brasil, entregar, entrega nacional, enviar', 'Sim, realizamos entregas em todo o território nacional através de transportadoras parceiras e dos Correios.', 'Envios'),
    ('Como faço para rastrear o meu pedido?', 'rastrear, rastreamento, rastrear pedido, onde está meu pedido, código, codigo', 'Assim que o seu pedido for despachado, você receberá um e-mail e uma notificação via WhatsApp com o código de rastreamento e o link para acompanhar a entrega.', 'Envios'),

    # Tamanhos e Modelagem
    ('Como sei qual é o tamanho ideal para mim?', 'tamanho, tamanhos, tamanho ideal, medidas, tabela de medidas, dimensão, dimensoes', 'Disponibilizamos uma tabela de medidas detalhada em todas as páginas de produto. Recomendamos que você meça uma camiseta sua que vista bem e compare com as nossas dimensões antes de fechar o pedido.', 'Tamanhos'),
    ('As camisetas são unissex?', 'unissex, camisetas unissex, baby look, oversized, corte, modelagem, feminina, masculino', 'Trabalhamos com diferentes modelagens. Temos opções de corte Tradicional (unissex), Baby Look (feminina) e Oversized. A modelagem exata está especificada na descrição de cada produto.', 'Tamanhos'),

    # Trocas e Devoluções
    ('A camiseta não serviu. Como faço para trocar?', 'troca, trocar, devolução, devolucao, trocas e devoluções, não serviu, nao serviu', 'Você tem até 7 dias corridos após o recebimento para solicitar a troca ou devolução gratuita, desde que a peça não tenha sido lavada ou usada e esteja com a etiqueta original.', 'Trocas'),
    ('Quem paga o frete em caso de troca?', 'frete em caso de troca, frete de troca, quem paga o frete, postagem reversa, custo de troca', 'A primeira troca do seu pedido é por nossa conta. Nós geramos um código de postagem reversa para você enviar o produto de volta sem custos.', 'Trocas'),

    # Cuidados com a Peça
    ('Como devo lavar minha camiseta para ela durar mais?', 'como lavar, lavar, lavagem, lavar camiseta, durar mais, alvejante, secadora, ferro', 'Recomendamos lavar as peças do avesso, evitar o uso de alvejantes e secar à sombra. Não utilize secadoras e evite passar o ferro diretamente sobre a estampa.', 'Cuidados'),
    ('O tecido encolhe na primeira lavagem?', 'tecido encolhe, encolhe, encolher, primeira lavagem, variação, algodão, algodao', 'Nossas camisetas são produzidas com malha pré-encolhida, reduzindo drasticamente o encolhimento. Contudo, o algodão pode apresentar uma variação natural de até 3% após a primeira lavagem se exposto a água morna ou secadoras.', 'Cuidados'),

    # Pagamentos e Segurança
    ('Quais são as formas de pagamento aceitas?', 'formas de pagamento, pagamento, pagamentos, aceitamos, pix, boleto, cartão, cartao, parcelar', 'Aceitamos Pix (com aprovação imediata e desconto), boleto bancário e cartões de crédito das principais bandeiras, com opção de parcelamento.', 'Pagamentos'),
    ('É seguro comprar no site?', 'segurança no site, segurança, seguro, comprar é seguro, ssl, criptografia, dados', 'Sim, nosso site conta com certificados de segurança SSL que criptografam todos os seus dados financeiros, garantindo uma compra 100% segura.', 'Segurança'),

    # Materiais Específicos do Catálogo
    ('De que material é a caneca?', 'caneca, canecas, material da caneca, cerâmica, ceramica, porcelana, lava louça, microondas', 'Nossas canecas são de cerâmica de alta qualidade, com estampa por sublimação de longa duração, que suporta micro-ondas e lava-louças com uso cuidadoso. Capacidade de 325 ml.', 'Materiais'),
    ('De que material é o botton/broche?', 'botton, bottons, broche, broches, pin, material do botton, metal, alfinete', 'Os bottons e broches têm base metálica com alfinete de segurança e estampa impressa protegida por camada de resina. Tamanho padrão de 4,5 cm, sob consulta para outros tamanhos.', 'Materiais'),
]

for pergunta, chaves, resposta, categoria in regras:
    ChatbotRegra.objects.update_or_create(
        pergunta=pergunta,
        defaults={'palavras_chave': chaves, 'resposta': resposta, 'categoria': categoria},
    )
    FAQItem.objects.update_or_create(
        business=perfil,
        question=pergunta,
        defaults={'answer': resposta, 'keywords': chaves, 'active': True},
    )

print('Banco populado com sucesso com as novas regras da MG Arts.')