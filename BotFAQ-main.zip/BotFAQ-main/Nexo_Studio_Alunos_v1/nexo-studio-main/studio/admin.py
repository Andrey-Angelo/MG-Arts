from django.contrib import admin
from .models import (
    RespostaChat, 
    HistoricoConversa, 
    Business, 
    Page, 
    Offering, 
    Activity, 
    FAQItem, 
    ChatInteraction
)

@admin.register(RespostaChat)
class RespostaChatAdmin(admin.ModelAdmin):
    list_display = ('pergunta', 'categoria', 'resposta')
    search_fields = ('pergunta', 'resposta', 'categoria')

@admin.register(HistoricoConversa)
class HistoricoConversaAdmin(admin.ModelAdmin):
    list_display = ('data_hora', 'pergunta', 'resposta')
    search_fields = ('pergunta', 'resposta')


class PageInline(admin.TabularInline): 
    model = Page
    extra = 0

@admin.register(Business)
class BusinessAdmin(admin.ModelAdmin): 
    list_display = ('name', 'owner', 'sector', 'published', 'created_at')
    search_fields = ('name', 'owner__username')
    prepopulated_fields = {}

# Registros
admin.site.register(Page)
admin.site.register(Offering)
admin.site.register(Activity)
admin.site.register(FAQItem)
admin.site.register(ChatInteraction)
