import os

files = {
    "studio/models.py": '''from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from django.utils.text import slugify

SETORES = [('gastronomia','Gastronomia'),('beleza','Beleza e bem-estar'),('servicos','Serviços profissionais'),('varejo','Varejo e loja'),('tecnologia','Tecnologia'),('educacao','Educação'),('outro','Outro negócio')]

class Business(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='businesses')
    name = models.CharField('Nome do negócio', max_length=120)
    slug = models.SlugField(unique=True, max_length=150)
    sector = models.CharField('Setor', max_length=30, choices=SETORES, default='servicos')
    tagline = models.CharField('Frase de apresentação', max_length=180, blank=True)
    description = models.TextField('Descrição', blank=True)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=40, blank=True)
    address = models.CharField(max_length=180, blank=True)
    logo = models.FileField(upload_to='logos/', blank=True)
    primary_color = models.CharField(max_length=7, default='#2563EB')
    secondary_color = models.CharField(max_length=7, default='#0F172A')
    accent_color = models.CharField(max_length=7, default='#EC4899')
    font_style = models.CharField(max_length=20, default='moderna', choices=[('moderna','Moderna'),('classica','Clássica'),('minimalista','Minimalista')])
    hero_image = models.URLField(blank=True)
    uploaded_hero = models.FileField(upload_to='business-images/', blank=True)
    published = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def save(self,*args,**kwargs):
        if not self.slug:
            base=slugify(self.name) or 'meu-negocio'; slug=base; n=2
            while Business.objects.filter(slug=slug).exclude(pk=self.pk).exists(): slug=f'{base}-{n}'; n+=1
            self.slug=slug
        super().save(*args,**kwargs)
    def __str__(self): return self.name

class Page(models.Model):
    business = models.ForeignKey(Business,on_delete=models.CASCADE,related_name='pages')
    title = models.CharField(max_length=100)
    slug = models.SlugField(max_length=120)
    body = models.TextField(blank=True)
    menu_label = models.CharField(max_length=50,blank=True)
    is_visible = models.BooleanField(default=True)
    sort_order = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta: ordering=['sort_order','title']; unique_together=[('business','slug')]
    def __str__(self): return self.title

class Offering(models.Model):
    TYPES=[('produto','Produto'),('servico','Serviço')]
    business=models.ForeignKey(Business,on_delete=models.CASCADE,related_name='offerings')
    kind=models.CharField(max_length=12,choices=TYPES,default='servico')
    name=models.CharField(max_length=120)
    description=models.TextField(blank=True)
    price=models.DecimalField(max_digits=10,decimal_places=2,default=0)
    image=models.CharField('Imagem (caminho estático)',max_length=255,blank=True)
    active=models.BooleanField(default=True)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta: ordering=['name']
    def __str__(self): return self.name
    @property
    def image_url(self):
        if not self.image: return ''
        path=self.image.lstrip('/')
        if path.startswith('static/'): path=path[len('static/'):]
        return settings.STATIC_URL.rstrip('/')+'/'+path

class Activity(models.Model):
    TYPES=[('lead','Novo contato'),('venda','Venda'),('agendamento','Agendamento'),('tarefa','Tarefa'),('outro','Outro')]
    STATUS=[('aberta','Aberta'),('em_andamento','Em andamento'),('concluida','Concluída'),('cancelada','Cancelada')]
    business=models.ForeignKey(Business,on_delete=models.CASCADE,related_name='activities')
    title=models.CharField(max_length=140)
    kind=models.CharField(max_length=20,choices=TYPES,default='tarefa')
    status=models.CharField(max_length=20,choices=STATUS,default='aberta')
    amount=models.DecimalField(max_digits=10,decimal_places=2,default=0)
    notes=models.TextField(blank=True)
    activity_date=models.DateField()
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta: ordering=['-activity_date','-created_at']
    def __str__(self): return self.title

class FAQItem(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name='faq_items')
    question = models.CharField('Pergunta', max_length=240)
    answer = models.TextField('Resposta')
    keywords = models.CharField('Palavras-chave', max_length=300, blank=True, help_text='Separe palavras e expressões por vírgula.')
    active = models.BooleanField('Ativa', default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        ordering = ['question']
        constraints = [models.UniqueConstraint(fields=['business', 'question'], name='unique_business_faq_question')]
    def __str__(self): return f'{self.business.name}: {self.question}'

class ChatInteraction(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name='chat_interactions')
    question = models.CharField(max_length=500)
    answer = models.TextField()
    matched_faq = models.ForeignKey(FAQItem, null=True, blank=True, on_delete=models.SET_NULL, related_name='interactions')
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta: ordering = ['-created_at']
    def __str__(self): return f'{self.business.name} — {self.created_at:%d/%m/%Y %H:%M}'

StudioProfile = Business
ListingPage = Page

class ChatbotRegra(models.Model):
    pergunta = models.CharField(max_length=240)
    palavras_chave = models.CharField(max_length=300)
    resposta = models.TextField()
    categoria = models.CharField(max_length=60, default='Geral')

    class Meta:
        ordering = ['categoria', 'pergunta']

    def __str__(self): return f'[{self.categoria}] {self.pergunta}'
''',

    "studio/views.py": '''import csv
import io
import re
import unicodedata
import json
from datetime import date, timedelta
from decimal import Decimal
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Sum
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render, redirect, get_object_or_404
from django.utils.text import slugify
from django.core.exceptions import ValidationError
from security.api_security import enforce_rate_limit
from security.validation import parse_json_object, clean_chat_question, MAX_JSON_BODY_BYTES
from security.audit import log_security_event
from security.authorization import get_business_or_404, get_owned_object_or_404
from .models import Business, Page, Offering, Activity, FAQItem, ChatInteraction, ChatbotRegra
from .forms import SignUpForm, BusinessForm, PageForm, OfferingForm, ActivityForm, FAQItemForm
from .sector_images import SECTOR_IMAGES

def landing(request):
    return render(request,'studio/landing.html')

def signup(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Conta criada! Vamos configurar seu negócio.')
            return redirect('business_create')
    else:
        form = SignUpForm()
    return render(request, 'studio/signup.html', {'form': form, 'title': 'Crie sua conta', 'subtitle': 'Seu próximo site começa aqui.'})

def owner_businesses(user): return Business.objects.filter(owner=user)

def current_business(request):
    businesses = owner_businesses(request.user)
    selected_id = request.session.get('active_business_id')
    if selected_id:
        selected = businesses.filter(pk=selected_id).first()
        if selected:
            return selected
    return businesses.order_by('id').first()

@login_required
def switch_business(request):
    if request.method != 'POST':
        return redirect('dashboard')
    business = get_business_or_404(user=request.user, business_id=request.POST.get('business_id'))
    request.session['active_business_id'] = business.pk
    messages.success(request, f'Negócio ativo: {business.name}.')
    return redirect('dashboard')

@login_required
def dashboard(request):
    businesses=owner_businesses(request.user)
    business=current_business(request)
    if not business: return redirect('business_create')
    activities=business.activities.all()[:6]
    today=date.today(); start=today-timedelta(days=6)
    daily=[]
    for i in range(7):
        day=start+timedelta(days=i)
        daily.append({'label':day.strftime('%d/%m'),'count':business.activities.filter(activity_date=day).count()})
    total_activities=business.activities.count()
    open_activities=business.activities.exclude(status__in=['concluida','cancelada']).count()
    revenue=business.activities.filter(kind='venda',status='concluida').aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
    context={'business':business,'businesses':businesses,'activities':activities,'daily':daily,'daily_json':json.dumps(daily),'total_activities':total_activities,'open_activities':open_activities,'revenue':revenue,'offerings_count':business.offerings.count(),'pages_count':business.pages.count()}
    return render(request,'studio/dashboard.html',context)

@login_required
def business_create(request):
    if request.method=='POST':
        form=BusinessForm(request.POST,request.FILES)
        if form.is_valid():
            business=form.save(commit=False); business.owner=request.user
            business.save()
            request.session['active_business_id'] = business.pk
            Page.objects.bulk_create([Page(business=business,title='Sobre nós',slug='sobre',menu_label='Sobre',body=business.description,sort_order=1),Page(business=business,title='Contato',slug='contato',menu_label='Contato',body='Entre em contato pelos canais informados.',sort_order=2)])
            messages.success(request,'Negócio criado! Seu site já tem uma estrutura inicial.')
            return redirect('dashboard')
    else: form=BusinessForm()
    return render(request,'studio/form_page.html',{'form':form,'title':'Configure seu negócio','subtitle':'Essas informações dão personalidade ao seu site.','wide':True})

@login_required
def business_edit(request):
    business=current_business(request)
    if not business: return redirect('business_create')
    if request.method=='POST':
        form=BusinessForm(request.POST,request.FILES,instance=business)
        if form.is_valid(): form.save(); messages.success(request,'Identidade do negócio atualizada.'); return redirect('business_edit')
    else: form=BusinessForm(instance=business)
    return render(request,'studio/form_page.html',{'form':form,'title':'Identidade do negócio','subtitle':'Personalize informações, cores, estilo e imagens.','wide':True,'business':business})

@login_required
def pages_list(request):
    b=current_business(request)
    if not b: return redirect('business_create')
    return render(request,'studio/list_pages.html',{'business':b,'items':b.pages.all()})

@login_required
def page_create(request):
    b=current_business(request)
    if request.method=='POST':
        form=PageForm(request.POST)
        if form.is_valid():
            item=form.save(commit=False); item.business=b; item.slug=slugify(item.title) or 'pagina'; base=item.slug; n=2
            while Page.objects.filter(business=b,slug=item.slug).exists(): item.slug=f'{base}-{n}'; n+=1
            if not item.menu_label: item.menu_label=item.title
            item.save(); messages.success(request,'Página criada.'); return redirect('pages_list')
    else: form=PageForm()
    return render(request,'studio/form_page.html',{'form':form,'title':'Nova página','subtitle':'Adicione conteúdo ao site.'})

@login_required
def page_edit(request,pk):
    b=current_business(request); item=get_owned_object_or_404(Page.objects.all(), business=b, object_id=pk)
    if request.method=='POST':
        form=PageForm(request.POST,instance=item)
        if form.is_valid():
            obj=form.save(commit=False); obj.slug=slugify(obj.title) or item.slug; obj.save(); messages.success(request,'Página atualizada.'); return redirect('pages_list')
    else: form=PageForm(instance=item)
    return render(request,'studio/form_page.html',{'form':form,'title':'Editar página','subtitle':'Atualize o conteúdo do site.'})

@login_required
def page_delete(request,pk):
    b=current_business(request); item=get_owned_object_or_404(Page.objects.all(), business=b, object_id=pk)
    if request.method=='POST': item.delete(); messages.success(request,'Página removida.')
    return redirect('pages_list')

@login_required
def offerings_list(request):
    b=current_business(request)
    if not b: return redirect('business_create')
    return render(request,'studio/list_offerings.html',{'business':b,'items':b.offerings.all()})

@login_required
def offering_create(request):
    b=current_business(request)
    if request.method=='POST':
        form=OfferingForm(request.POST)
        if form.is_valid(): item=form.save(commit=False); item.business=b; item.save(); messages.success(request,'Item cadastrado.'); return redirect('offerings_list')
    else: form=OfferingForm()
    return render(request,'studio/form_page.html',{'form':form,'title':'Novo produto ou serviço','subtitle':'Cadastre o que seu negócio oferece.'})

@login_required
def offering_edit(request,pk):
    b=current_business(request); item=get_owned_object_or_404(Offering.objects.all(), business=b, object_id=pk)
    if request.method=='POST':
        form=OfferingForm(request.POST,instance=item)
        if form.is_valid(): form.save(); messages.success(request,'Cadastro atualizado.'); return redirect('offerings_list')
    else: form=OfferingForm(instance=item)
    return render(request,'studio/form_page.html',{'form':form,'title':'Editar produto ou serviço','subtitle':'Atualize as informações.'})

@login_required
def offering_delete(request,pk):
    b=current_business(request); item=get_owned_object_or_404(Offering.objects.all(), business=b, object_id=pk)
    if request.method=='POST': item.delete(); messages.success(request,'Cadastro removido.')
    return redirect('offerings_list')

@login_required
def activities_list(request):
    b=current_business(request)
    if not b: return redirect('business_create')
    items=b.activities.all()
    kind=request.GET.get('kind'); status=request.GET.get('status')
    if kind: items=items.filter(kind=kind)
    if status: items=items.filter(status=status)
    return render(request,'studio/list_activities.html',{'business':b,'items':items,'selected_kind':kind or '', 'selected_status':status or ''})

@login_required
def activity_create(request):
    b=current_business(request)
    if request.method=='POST':
        form=ActivityForm(request.POST)
        if form.is_valid(): item=form.save(commit=False); item.business=b; item.save(); messages.success(request,'Movimentação registrada.'); return redirect('activities_list')
    else: form=ActivityForm(initial={'activity_date':date.today()})
    return render(request,'studio/form_page.html',{'form':form,'title':'Nova movimentação','subtitle':'Registre contatos, vendas, agendamentos ou tarefas.'})

@login_required
def activity_edit(request,pk):
    b=current_business(request); item=get_owned_object_or_404(Activity.objects.all(), business=b, object_id=pk)
    if request.method=='POST':
        form=ActivityForm(request.POST,instance=item)
        if form.is_valid(): form.save(); messages.success(request,'Movimentação atualizada.'); return redirect('activities_list')
    else: form=ActivityForm(instance=item)
    return render(request,'studio/form_page.html',{'form':form,'title':'Editar movimentação','subtitle':'Atualize os dados do registro.'})

@login_required
def activity_delete(request,pk):
    b=current_business(request); item=get_owned_object_or_404(Activity.objects.all(), business=b, object_id=pk)
    if request.method=='POST': item.delete(); messages.success(request,'Movimentação removida.')
    return redirect('activities_list')

@login_required
def reports(request):
    b=current_business(request)
    if not b: return redirect('business_create')
    by_kind=list(b.activities.values('kind').annotate(total=Count('id')).order_by('kind'))
    by_status=list(b.activities.values('status').annotate(total=Count('id')).order_by('status'))
    sales=b.activities.filter(kind='venda',status='concluida').aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
    return render(request,'studio/reports.html',{'business':b,'by_kind':by_kind,'by_status':by_status,'sales':sales,'total':b.activities.count(),'offerings':b.offerings.count()})

@login_required
def export_csv(request):
    b=current_business(request)
    response=HttpResponse(content_type='text/csv; charset=utf-8-sig')
    response['Content-Disposition']='attachment; filename="relatorio-movimentacoes.csv"'
    writer=csv.writer(response,delimiter=';'); writer.writerow(['Data','Título','Tipo','Status','Valor (R$)','Observações'])
    for a in b.activities.all(): writer.writerow([a.activity_date,a.title,a.get_kind_display(),a.get_status_display(),a.amount,a.notes])
    return response

@login_required
def image_library(request):
    b=current_business(request)
    if not b: return redirect('business_create')
    return render(request,'studio/image_library.html',{'business':b,'images':SECTOR_IMAGES.get(b.sector,SECTOR_IMAGES['outro'])})

@login_required
def choose_image(request,index):
    b=current_business(request)
    images=SECTOR_IMAGES.get(b.sector,SECTOR_IMAGES['outro'])
    if request.method=='POST' and index>=0 and index<len(images):
        b.hero_image=images[index][1]; b.save(update_fields=['hero_image','updated_at']); messages.success(request,'Imagem selecionada para o destaque do site.')
    return redirect('image_library')

def public_site(request,slug):
    b=get_object_or_404(Business,slug=slug,published=True)
    pages=b.pages.filter(is_visible=True); offerings=b.offerings.filter(active=True); activities=b.activities.all()[:12]
    return render(request,'studio/public_site.html',{'business':b,'pages':pages,'offerings':offerings,'activities':activities})

def _normalize_text(value):
    value = unicodedata.normalize('NFKD', value or '').encode('ascii', 'ignore').decode('ascii').lower()
    return re.sub(r'[^a-z0-9 ]+', ' ', value).strip()

@login_required
def faq_list(request):
    business = current_business(request)
    if not business: return redirect('business_create')
    return render(request, 'studio/faq_list.html', {'business': business, 'items': business.faq_items.all()})

@login_required
def faq_create(request):
    business = current_business(request)
    if request.method == 'POST':
        form = FAQItemForm(request.POST)
        if form.is_valid():
            item = form.save(commit=False); item.business = business
            try: item.save()
            except Exception:
                form.add_error('question', 'Já existe uma pergunta igual cadastrada para este negócio.')
            else:
                messages.success(request, 'Pergunta e resposta cadastradas.'); return redirect('faq_list')
    else: form = FAQItemForm()
    return render(request, 'studio/form_page.html', {'form': form, 'title': 'Nova pergunta e resposta', 'subtitle': 'Alimente a base de conhecimento do chatbot.'})

@login_required
def faq_edit(request, pk):
    business = current_business(request); item = get_owned_object_or_404(FAQItem.objects.all(), business=business, object_id=pk)
    if request.method == 'POST':
        form = FAQItemForm(request.POST, instance=item)
        if form.is_valid(): form.save(); messages.success(request, 'Pergunta atualizada.'); return redirect('faq_list')
    else: form = FAQItemForm(instance=item)
    return render(request, 'studio/form_page.html', {'form': form, 'title': 'Editar pergunta e resposta', 'subtitle': 'Atualize a resposta usada pelo chatbot.'})

@login_required
def faq_delete(request, pk):
    business = current_business(request); item = get_owned_object_or_404(FAQItem.objects.all(), business=business, object_id=pk)
    if request.method == 'POST': item.delete(); messages.success(request, 'Pergunta removida da base.')
    return redirect('faq_list')

@login_required
def faq_import(request):
    business = current_business(request)
    if request.method != 'POST' or 'file' not in request.FILES:
        messages.error(request, 'Selecione um arquivo CSV para importar.'); return redirect('faq_list')
    uploaded = request.FILES['file']
    if uploaded.size > 1024 * 1024:
        messages.error(request, 'O arquivo deve ter no máximo 1 MB.'); return redirect('faq_list')
    try:
        content = uploaded.read().decode('utf-8-sig')
        reader = csv.DictReader(io.StringIO(content), delimiter=';')
        fields = {x.strip().lower() for x in (reader.fieldnames or [])}
        if not {'pergunta', 'resposta'}.issubset(fields): raise ValueError('O CSV precisa ter as colunas pergunta;resposta e, opcionalmente, palavras_chave;ativa.')
        count = 0
        for row in reader:
            row = {str(k).strip().lower(): (v or '').strip() for k, v in row.items() if k}
            question, answer = row.get('pergunta', ''), row.get('resposta', '')
            if not question or not answer: continue
            FAQItem.objects.update_or_create(business=business, question=question, defaults={'answer': answer, 'keywords': row.get('palavras_chave', ''), 'active': row.get('ativa', 'sim').lower() not in ('nao','não','0','false')})
            count += 1
        messages.success(request, f'{count} pergunta(s) importada(s) ou atualizada(s).')
    except (UnicodeDecodeError, csv.Error, ValueError) as exc:
        messages.error(request, f'Não foi possível importar o arquivo: {exc}')
    return redirect('faq_list')

@csrf_exempt
def chatbot_api(request, slug):
    if request.method != 'POST':
        response = JsonResponse({'erro': 'Use POST com JSON {"pergunta": "..."}.'}, status=405)
        response['Allow'] = 'POST'
        return response
    if request.content_type != 'application/json':
        return JsonResponse({'erro': 'Content-Type deve ser application/json.'}, status=415)
    try:
        content_length = int(request.META.get('CONTENT_LENGTH') or 0)
    except (TypeError, ValueError):
        return JsonResponse({'erro': 'Content-Length inválido.'}, status=400)
    if content_length > MAX_JSON_BODY_BYTES:
        log_security_event('chat_payload_too_large', request=request, detail=f'bytes={content_length}')
        return JsonResponse({'erro': 'A requisição excede o tamanho máximo permitido.'}, status=413)
    limited = enforce_rate_limit(request, scope=f'chat:{slug}')
    if limited:
        log_security_event('chat_rate_limit', request=request, detail=f'slug={slug}')
        return limited
    business = get_object_or_404(Business, slug=slug, published=True)
    try:
        payload = parse_json_object(request.body)
        question = clean_chat_question(payload.get('pergunta', ''))
    except ValidationError as exc:
        return JsonResponse({'erro': str(exc.message if hasattr(exc, 'message') else exc.messages[0])}, status=400)
    normalized = _normalize_text(question)
    best, best_score = None, 0
    for faq in business.faq_items.filter(active=True):
        candidates = [faq.question] + [k.strip() for k in faq.keywords.split(',') if k.strip()]
        score = 0
        for candidate in candidates:
            candidate_norm = _normalize_text(candidate)
            if candidate_norm and candidate_norm in normalized:
                score = max(score, len(candidate_norm) + 10)
            else:
                words = [w for w in candidate_norm.split() if len(w) > 2]
                overlap = sum(1 for word in words if word in normalized.split())
                score = max(score, overlap)
        if score > best_score:
            best, best_score = faq, score
    if best and best_score >= 1:
        answer = best.answer
        matched = best
    else:
        answer = f'Obrigado pelo contato com {business.name}! Ainda não encontrei uma resposta específica para essa pergunta. Entre em contato pelo e-mail {business.email or "informado no site"} ou telefone {business.phone or "disponível na página"}.'
        matched = None
    ChatInteraction.objects.create(business=business, question=question, answer=answer, matched_faq=matched)
    return JsonResponse({'resposta': answer, 'encontrada': bool(matched), 'negocio': business.name})

def api_documentation(request):
    return JsonResponse({'nome': 'Nexo Studio Chatbot API', 'versao': '1.1', 'endpoint': '/api/chat/<slug>/', 'metodo': 'POST', 'content_type': 'application/json'})

def api_chatbot(request):
    limited = enforce_rate_limit(request, scope='chatbot_regras')
    if limited:
        return limited
    q = (request.GET.get('q') or '').strip()[:500]
    if len(q) < 2:
        return JsonResponse({'resposta': 'Digite sua pergunta para que eu possa ajudar.'})
    normalized = ' ' + _normalize_text(q) + ' '
    best, best_score = None, 0
    for regra in ChatbotRegra.objects.all():
        for palavra in regra.palavras_chave.split(','):
            termo = _normalize_text(palavra)
            if termo and (' ' + termo + ' ') in normalized and len(termo) > best_score:
                best, best_score = regra, len(termo)
    if best is None:
        for regra in ChatbotRegra.objects.all():
            for palavra in regra.palavras_chave.split(','):
                termo = _normalize_text(palavra)
                if termo and termo in normalized and len(termo) > best_score:
                    best, best_score = regra, len(termo)
    if best:
        return JsonResponse({'resposta': best.resposta})
    return JsonResponse({'resposta': 'Ainda não encontrei uma resposta para isso. Fale com a MG Arts pelo WhatsApp ou e-mail e teremos prazer em ajudar!'})
''',

    "studio/urls.py": '''from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path("", views.landing, name="landing"),
    path("conta/criar/", views.signup, name="signup"),
    path("conta/entrar/", auth_views.LoginView.as_view(template_name="studio/login.html"), name="login"),
    path("conta/sair/", auth_views.LogoutView.as_view(), name="logout"),

    path("painel/", views.dashboard, name="dashboard"),
    path("negocio/selecionar/", views.switch_business, name="switch_business"),
    path("negocio/novo/", views.business_create, name="business_create"),
    path("negocio/identidade/", views.business_edit, name="business_edit"),

    path("paginas/", views.pages_list, name="pages_list"),
    path("paginas/nova/", views.page_create, name="page_create"),
    path("paginas/<int:pk>/editar/", views.page_edit, name="page_edit"),
    path("paginas/<int:pk>/excluir/", views.page_delete, name="page_delete"),

    path("catalogo/", views.offerings_list, name="offerings_list"),
    path("catalogo/novo/", views.offering_create, name="offering_create"),
    path("catalogo/<int:pk>/editar/", views.offering_edit, name="offering_edit"),
    path("catalogo/<int:pk>/excluir/", views.offering_delete, name="offering_delete"),

    path("movimentacoes/", views.activities_list, name="activities_list"),
    path("movimentacoes/nova/", views.activity_create, name="activity_create"),
    path("movimentacoes/<int:pk>/editar/", views.activity_edit, name="activity_edit"),
    path("movimentacoes/<int:pk>/excluir/", views.activity_delete, name="activity_delete"),

    path("relatorios/", views.reports, name="reports"),
    path("relatorios/exportar/", views.export_csv, name="export_csv"),

    path("imagens/", views.image_library, name="image_library"),
    path("imagens/<int:index>/selecionar/", views.choose_image, name="choose_image"),

    path("perguntas/", views.faq_list, name="faq_list"),
    path("perguntas/nova/", views.faq_create, name="faq_create"),
    path("perguntas/<int:pk>/editar/", views.faq_edit, name="faq_edit"),
    path("perguntas/<int:pk>/excluir/", views.faq_delete, name="faq_delete"),
    path("perguntas/importar/", views.faq_import, name="faq_import"),

    path("api/chat/<slug:slug>/", views.chatbot_api, name="chatbot_api"),
    path("api/chatbot/", views.api_chatbot, name="api_chatbot"),
    path("api/documentacao/", views.api_documentation, name="api_documentation"),

    path("s/<slug:slug>/", views.public_site, name="public_site"),
]
''',

    "templates/studio/public_site.html": '''<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ business.name }}</title>
<style>
:root{--primary:#2563EB;--accent:#EC4899;--bg:#F8FAFC;--text:#0F172A;--card:#FFFFFF;--muted:#64748B;--border:#E2E8F0}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:var(--bg);color:var(--text);line-height:1.6}
header.top{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;padding:18px 7%;background:var(--card);border-bottom:1px solid var(--border)}
.brand{font-size:22px;font-weight:800;color:var(--primary)}
.brand span{color:var(--accent)}
nav a{margin-left:18px;color:var(--text);text-decoration:none;font-weight:600}
nav a:hover{color:var(--accent)}
.hero{padding:70px 7% 50px;text-align:center}
.hero h1{font-size:clamp(30px,5vw,52px);line-height:1.15;margin-bottom:14px}
.hero p{max-width:640px;margin:0 auto 24px;color:var(--muted);font-size:18px}
.btn{display:inline-block;background:var(--primary);color:#fff;padding:13px 26px;border-radius:999px;font-weight:700;text-decoration:none;border:0;cursor:pointer}
.btn:hover{background:var(--accent)}
section.block{padding:40px 7%}
section.block h2{font-size:28px;margin-bottom:6px}
section.block h2::after{content:"";display:block;width:54px;height:4px;border-radius:4px;background:var(--accent);margin-top:8px}
section.block>p.sub{color:var(--muted);margin:12px 0 26px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:22px}
.card{background:var(--card);border:1px solid var(--border);border-radius:18px;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 6px 20px #0f172a0d;transition:transform .2s,box-shadow .2s}
.card:hover{transform:translateY(-4px);box-shadow:0 14px 30px #2563eb22}
.thumb{height:190px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;color:#fff;font-size:42px;overflow:hidden}
.thumb img{width:100%;height:100%;object-fit:cover;display:block}
.card-body{padding:18px;display:flex;flex-direction:column;gap:8px;flex:1}
.card-body h3{font-size:18px}
.card-body p{color:var(--muted);font-size:14px;flex:1}
.price{font-size:22px;font-weight:800;color:var(--primary)}
.tag{align-self:flex-start;background:#ec489918;color:var(--accent);font-size:12px;font-weight:700;padding:3px 10px;border-radius:999px}
footer{padding:30px 7%;background:var(--text);color:#cbd5e1;text-align:center;margin-top:30px}
footer strong{color:#fff}
#chat-toggle{position:fixed;right:22px;bottom:22px;z-index:1000;border:0;border-radius:999px;padding:15px 20px;background:var(--accent);color:#fff;font-weight:800;font-size:15px;cursor:pointer;box-shadow:0 10px 30px #ec489955}
#chat-box{display:none;position:fixed;right:22px;bottom:82px;z-index:1000;width:min(370px,calc(100vw - 32px));height:440px;background:var(--card);border:1px solid var(--border);border-radius:18px;box-shadow:0 20px 55px #0f172a33;overflow:hidden;flex-direction:column}
#chat-box header{padding:14px 16px;background:var(--primary);color:#fff;display:flex;justify-content:space-between;align-items:center}
#chat-close{border:0;background:transparent;color:#fff;font-size:24px;cursor:pointer;line-height:1}
#chat-log{flex:1;overflow:auto;padding:14px;display:flex;flex-direction:column;gap:8px;font-size:14px;background:var(--bg)}
.msg{padding:10px 13px;border-radius:14px;max-width:85%;white-space:pre-wrap;word-wrap:break-word}
.msg.bot{background:#fff;border:1px solid var(--border);align-self:flex-start}
.msg.user{background:var(--primary);color:#fff;align-self:flex-end}
#chat-form{display:flex;gap:8px;padding:12px;border-top:1px solid var(--border);background:#fff}
#chat-input{flex:1;min-width:0;border:1px solid var(--border);border-radius:10px;padding:10px;font-size:14px;color:var(--text)}
#chat-form button{border:0;border-radius:10px;padding:10px 14px;background:var(--primary);color:#fff;font-weight:700;cursor:pointer}
#chat-form button:hover{background:var(--accent)}
@media(max-width:600px){nav{display:none}.hero{padding:44px 6% 30px}}
</style>
</head>
<body>
<header class="top">
<div class="brand">MG <span>Arts</span></div>
<nav><a href="#produtos">Produtos</a><a href="#portfolio">Portfólio</a><a href="#contato">Contato</a></nav>
</header>
<div class="hero">
<h1>{{ business.tagline|default:"Estampas exclusivas que contam a sua história" }}</h1>
<p>{{ business.description|default:"Canecas, camisetas e bottons personalizados com arte autoral." }}</p>
<a class="btn" href="#produtos">Ver produtos</a>
</div>
<section class="block" id="produtos">
<h2>Nossos produtos</h2>
<p class="sub">Peças personalizadas feitas com carinho e acabamento profissional.</p>
<div class="grid">
{% for o in offerings %}
<article class="card">
<div class="thumb">{% if o.image_url %}<img src="{{ o.image_url }}" alt="{{ o.name }}" loading="lazy" onerror="this.remove()">{% else %}✦{% endif %}</div>
<div class="card-body">
<span class="tag">{{ o.get_kind_display }}</span>
<h3>{{ o.name }}</h3>
<p>{{ o.description }}</p>
<div class="price">R$ {{ o.price|floatformat:2 }}</div>
</div>
</article>
{% empty %}
<p>Nenhum produto disponível no momento.</p>
{% endfor %}
</div>
</section>
<section class="block" id="portfolio">
<h2>Portfólio de estampas</h2>
<p class="sub">Alguns trabalhos que já saíram do nosso ateliê.</p>
<div class="grid">
{% for a in activities %}
<article class="card">
<div class="thumb">🎨</div>
<div class="card-body">
<span class="tag">{{ a.activity_date|date:"d/m/Y" }}</span>
<h3>{{ a.title }}</h3>
<p>{{ a.notes }}</p>
</div>
</article>
{% empty %}
<p>Em breve novas estampas no portfólio.</p>
{% endfor %}
</div>
</section>
<footer id="contato">
<p><strong>{{ business.name }}</strong></p>
{% if business.email %}<p>{{ business.email }}</p>{% endif %}
{% if business.phone %}<p>{{ business.phone }}</p>{% endif %}
{% if business.address %}<p>{{ business.address }}</p>{% endif %}
</footer>
<button id="chat-toggle" type="button" aria-label="Abrir chat">💬 Fale conosco</button>
<section id="chat-box" aria-label="Chat de atendimento">
<header><strong>Atendimento · MG Arts</strong><button id="chat-close" type="button" aria-label="Fechar chat">×</button></header>
<div id="chat-log"></div>
<form id="chat-form" autocomplete="off">
<input id="chat-input" maxlength="500" required placeholder="Digite sua pergunta...">
<button type="submit">Enviar</button>
</form>
</section>
<script>
(function(){
var toggle=document.getElementById('chat-toggle');
var box=document.getElementById('chat-box');
var closeBtn=document.getElementById('chat-close');
var form=document.getElementById('chat-form');
var input=document.getElementById('chat-input');
var log=document.getElementById('chat-log');
function addMessage(text,who){
var div=document.createElement('div');
div.className='msg '+who;
div.textContent=text;
log.appendChild(div);
log.scrollTop=log.scrollHeight;
return div;
}
addMessage('Olá! Sou o assistente da MG Arts. Pergunte sobre produtos, prazos, pagamento, orçamentos e mais.','bot');
toggle.addEventListener('click',function(){
box.style.display=box.style.display==='flex'?'none':'flex';
if(box.style.display==='flex'){input.focus();}
});
closeBtn.addEventListener('click',function(){box.style.display='none';});
form.addEventListener('submit',function(e){
e.preventDefault();
var q=input.value.trim();
if(!q){return;}
addMessage(q,'user');
input.value='';
var waiting=addMessage('Digitando...','bot');
fetch('/api/chatbot/?q='+encodeURIComponent(q))
.then(function(r){return r.json();})
.then(function(data){waiting.textContent=data.resposta||data.erro||'Não foi possível responder.';log.scrollTop=log.scrollHeight;})
.catch(function(){waiting.textContent='Não foi possível conectar. Tente novamente mais tarde.';});
});
})();
</script>
</body>
</html>
''',

    "popular_site.py": '''import os
import django
from datetime import date

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from decimal import Decimal
from django.contrib.auth.models import User
from studio.models import StudioProfile, ListingPage, Offering, Activity, ChatbotRegra

EMAIL = 'contato@mgarts.com.br'
WHATSAPP = '(11) 98888-7777'

user, criado = User.objects.get_or_create(
    username='mgarts',
    defaults={'email': EMAIL, 'first_name': 'MG', 'last_name': 'Arts'},
)
if criado:
    user.set_password('mgarts@2026')
    user.save()

perfil, _ = StudioProfile.objects.update_or_create(
    slug='mg-arts',
    defaults={
        'owner': user,
        'name': 'MG Arts',
        'sector': 'varejo',
        'tagline': 'Estampas exclusivas que contam a sua história',
        'description': 'Canecas, camisetas e bottons personalizados com arte autoral, feitos sob encomenda com acabamento profissional.',
        'email': EMAIL,
        'phone': WHATSAPP,
        'address': 'Atendimento online com envio para todo o Brasil',
        'primary_color': '#2563EB',
        'secondary_color': '#0F172A',
        'accent_color': '#EC4899',
        'published': True,
    },
)

ListingPage.objects.update_or_create(
    business=perfil,
    slug='inicio',
    defaults={
        'title': 'Início',
        'body': 'Bem-vindo à MG Arts! Conheça nossas estampas exclusivas em canecas, camisetas e bottons personalizados.',
        'menu_label': 'Início',
        'is_visible': True,
        'sort_order': 1,
    },
)

ofertas = [
    ('Caneca Personalizada', 'Caneca com estampa exclusiva, criada sob medida com cores vibrantes e acabamento resistente para o uso diário.', '39.90', 'static/images/caneca.jpg'),
    ('Camiseta / Blusa Estampada', 'Camiseta ou blusa com estampa artesanal em silk, durável, confortável e com design autoral.', '79.90', 'static/images/blusa.jpg'),
    ('Botton / Broche Personalizado', 'Botton ou broche com estampa colecionável, ideal para mochilas, jaquetas e presentes criativos.', '12.90', 'static/images/botton.jpg'),
]
for nome, descricao, preco, imagem in ofertas:
    Offering.objects.update_or_create(
        business=perfil,
        name=nome,
        defaults={
            'kind': 'produto',
            'description': descricao,
            'price': Decimal(preco),
            'image': imagem,
            'active': True,
        },
    )

atividades = [
    ('Coleção Flores do Cerrado', 'Galeria de estampas florais autorais aplicadas em canecas e camisetas, com paleta azul e rosa.'),
    ('Série Colecionável Pixel Art', 'Portfólio de estampas em pixel art transformadas em bottons e broches de edição limitada.'),
]
for titulo, notas in atividades:
    Activity.objects.update_or_create(
        business=perfil,
        title=titulo,
        defaults={
            'kind': 'outro',
            'status': 'concluida',
            'amount': Decimal('0'),
            'notes': notas,
            'activity_date': date.today(),
        },
    )

regras = [
    ('Quais serviços e produtos vocês oferecem?', 'serviço, serviços, servicos, produtos, o que vocês fazem, o que fazem, catálogo, catalogo', 'A MG Arts cria produtos personalizados com estampas exclusivas: canecas, camisetas/blusas em silk e bottons/broches colecionáveis.', 'Serviços'),
    ('Como peço um orçamento?', 'orçamento, orcamento, cotação, cotacao, quanto custa, valor, preço, preco, preços', 'Para um orçamento, envie a arte ou a ideia, o produto e a quantidade pelo WhatsApp ' + WHATSAPP + ' ou pelo e-mail ' + EMAIL + '. Respondemos rapidamente! Valores a partir de: bottons R$ 12,90, canecas R$ 39,90 e camisetas R$ 79,90.', 'Orçamentos'),
    ('Qual o prazo de produção e entrega?', 'prazo, prazos, entrega, demora, quanto tempo, enviar, envio, frete', 'O prazo de produção é de 3 a 7 dias úteis, dependendo do produto e da quantidade. O envio para todo o Brasil leva de 3 a 10 dias úteis, conforme sua região.', 'Prazos'),
    ('Quais as formas de pagamento?', 'pagamento, pagar, pix, cartão, cartao, parcelar, parcelamento, boleto', 'Aceitamos Pix, cartão de crédito em até 3x sem juros e transferência bancária. A produção começa após a confirmação do pagamento.', 'Pagamento'),
    ('Onde vocês ficam?', 'localização, localizacao, endereço, endereco, onde fica, onde ficam, loja física, loja fisica, retirada', 'A MG Arts atende online e envia para todo o Brasil. Para retirada em mãos, combine previamente pelo WhatsApp ' + WHATSAPP + '.', 'Localização'),
    ('Qual o horário de atendimento?', 'horário, horario, horas, funcionamento, atendimento, aberto, abre, fecha', 'Atendemos de segunda a sexta, das 9h às 18h, e aos sábados, das 9h às 13h. Mensagens fora do horário são respondidas no próximo dia útil.', 'Horário'),
    ('Como entro em contato?', 'contato, contatos, telefone, whatsapp, email, e-mail, falar, instagram', 'Fale com a MG Arts pelo WhatsApp ' + WHATSAPP + ' ou pelo e-mail ' + EMAIL + '.', 'Contato'),
    ('De que material é a caneca?', 'caneca, canecas, material da caneca, cerâmica, ceramica, porcelana, lava louça, microondas', 'Nossas canecas são de cerâmica de alta qualidade, com estampa por sublimação de longa duração, que suporta micro-ondas e lava-louças com uso cuidadoso. Capacidade de 325 ml.', 'Materiais'),
    ('De que material é a camiseta/blusa?', 'camiseta, camisetas, blusa, blusas, tecido, algodão, algodao, silk, serigrafia, malha, lavagem', 'Nossas camisetas e blusas são de malha 100% algodão, com estampa artesanal em silk (serigrafia). Para durar mais, lave do avesso em água fria e evite alvejante.', 'Materiais'),
    ('De que material é o botton/broche?', 'botton, bottons, broche, broches, pin, material do botton, metal, alfinete', 'Os bottons e broches têm base metálica com alfinete de segurança e estampa impressa protegida por camada de resina. Tamanho padrão de 4,5 cm, sob consulta para outros tamanhos.', 'Materiais'),
]
for pergunta, chaves, resposta, categoria in regras:
    ChatbotRegra.objects.update_or_create(
        pergunta=pergunta,
        defaults={'palavras_chave': chaves, 'resposta': resposta, 'categoria': categoria},
    )

print('Banco populado com sucesso.')
'''
}

for path, content in files.items():
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

print("Todos os 5 arquivos foram montados com sucesso!")